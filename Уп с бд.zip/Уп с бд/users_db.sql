-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Янв 29 2025 г., 07:31
-- Версия сервера: 8.0.30
-- Версия PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `users_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `auth`
--

CREATE TABLE `auth` (
  `id` int NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `user_session` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `order_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','completed','canceled') COLLATE utf8mb4_general_ci DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_date`, `total_amount`, `status`) VALUES
(1, 33, '2025-01-24 13:47:23', '3192.00', 'pending'),
(2, 33, '2025-01-24 13:49:32', '456.00', 'pending'),
(3, 33, '2025-01-24 13:50:50', '456.00', 'pending'),
(4, 33, '2025-01-24 13:54:33', '456.00', 'pending'),
(5, 33, '2025-01-24 14:24:10', '456.00', 'pending'),
(6, 33, '2025-01-29 07:28:40', '456.00', 'pending'),
(7, 39, '2025-01-29 07:30:18', '456.00', 'pending');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `price` decimal(10,2) NOT NULL,
  `image_primary` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rating` int DEFAULT '0',
  `category_id` int DEFAULT NULL,
  `color_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image_primary`, `rating`, `category_id`, `color_id`, `created_at`) VALUES
(2, 'Мыло №2', 'Описание товара', '675.00', 'assets/images/product/medium-size/2.jpg', 5, 1, 1, '2025-01-23 05:25:23'),
(5, 'Мыло №1', NULL, '456.00', 'assets/images/product/medium-size/2.jpg', 0, NULL, NULL, '2025-01-24 08:52:27'),
(6, 'Мыло №3', NULL, '456.00', 'assets/images/product/medium-size/2.jpg', 0, NULL, NULL, '2025-01-24 08:52:33'),
(7, 'Мыло №4', NULL, '456.00', 'assets/images/product/medium-size/2.jpg', 0, NULL, NULL, '2025-01-24 08:52:37'),
(12, 'Мыло №5', NULL, '456.00', 'assets/images/product/medium-size/2.jpg', 0, NULL, NULL, '2025-01-24 10:53:58'),
(13, 'Мыло №6', NULL, '456.00', 'assets/images/product/medium-size/2.jpg', 0, NULL, NULL, '2025-01-24 10:54:08'),
(14, 'Мыло №5555', NULL, '456.00', 'assets/images/product/medium-size/2.jpg', 0, NULL, NULL, '2025-01-29 04:29:38');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'user',
  `session_id` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `role`, `session_id`) VALUES
(33, 'user@mail.ru', '$2y$10$p.NhL9zAFuGRXWmltjR6ouX03jxLCA5CxMsDsax881XLlqVTLvLse', 'user', ''),
(34, 'admin@mail.ru', '$2y$10$9Ys3xbp24DAkXsejIUl5Q.sZU.PGarEKBF8/KLbC7.VlwsHlpV3bS', 'admin', ''),
(39, 'potomy4to_gladiolys@mail.ru', '$2y$10$ytlyJtN.sUF4VppJYaZv8eGZ/abcQLM2w5lpJF1zoG2JOjrSXxyQ6', 'user', '5bp9opdid47u1pm6pgcjgj7n7theb7cj'),
(40, 'vaaaleeerkaaa@yandex.ru', '$2y$10$PdkWSf5HAcIEQWgs2o7dEe9cb3DTaLThy16Q8GFYvWPIpDDqXyhcu', 'user', '5bp9opdid47u1pm6pgcjgj7n7theb7cj');

-- --------------------------------------------------------

--
-- Структура таблицы `user_login_history`
--

CREATE TABLE `user_login_history` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` enum('admin','user') COLLATE utf8mb4_general_ci NOT NULL,
  `login_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user_login_history`
--

INSERT INTO `user_login_history` (`id`, `user_id`, `email`, `role`, `login_time`) VALUES
(12, 30, 'admin@mail.ru', 'admin', '2025-01-24 08:07:19'),
(13, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:09:44'),
(14, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:10:02'),
(15, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:27:52'),
(16, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:30:56'),
(17, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:35:33'),
(18, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:37:22'),
(19, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:41:29'),
(20, 33, 'user@mail.ru', 'user', '2025-01-24 11:41:58'),
(21, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:46:03'),
(22, 34, 'admin@mail.ru', 'admin', '2025-01-24 11:49:41'),
(23, 33, 'user@mail.ru', 'user', '2025-01-24 11:57:00'),
(24, 33, 'user@mail.ru', 'user', '2025-01-24 12:00:42'),
(25, 34, 'admin@mail.ru', 'admin', '2025-01-24 12:00:59'),
(26, 33, 'user@mail.ru', 'user', '2025-01-24 12:02:24'),
(27, 34, 'admin@mail.ru', 'admin', '2025-01-24 12:03:09'),
(28, 33, 'user@mail.ru', 'user', '2025-01-24 12:04:23'),
(29, 34, 'admin@mail.ru', 'admin', '2025-01-24 13:53:41'),
(30, 33, 'user@mail.ru', 'user', '2025-01-24 13:54:25'),
(31, 33, 'user@mail.ru', 'user', '2025-01-24 14:05:27'),
(32, 34, 'admin@mail.ru', 'admin', '2025-01-29 07:29:25'),
(33, 39, 'potomy4to_gladiolys@mail.ru', 'user', '2025-01-29 07:30:09');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `user_login_history`
--
ALTER TABLE `user_login_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `auth`
--
ALTER TABLE `auth`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT для таблицы `user_login_history`
--
ALTER TABLE `user_login_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
