<?php
session_start();
include 'db.php';

if (isset($_POST['add_to_cart'])) {
    $product_id = intval($_POST['product_id']); // Преобразуем ID в целое число
    $quantity = intval($_POST['quantity']); // Преобразуем количество в целое число
    $user_session = session_id(); // Получаем ID текущей сессии

    if ($product_id > 0 && $quantity > 0) {
        // Проверяем, есть ли товар уже в корзине
        $check_cart = "SELECT * FROM cart WHERE product_id = $product_id AND user_session = '$user_session'";
        $result = $conn->query($check_cart);

        if ($result->num_rows > 0) {
            // Если товар уже в корзине, обновляем количество
            $update_cart = "UPDATE cart SET quantity = quantity + $quantity WHERE product_id = $product_id AND user_session = '$user_session'";
            if (!$conn->query($update_cart)) {
                die("Ошибка обновления корзины: " . $conn->error);
            }
        } else {
            // Если товара нет в корзине, добавляем его
            $add_cart = "INSERT INTO cart (product_id, quantity, user_session) VALUES ($product_id, $quantity, '$user_session')";
            if (!$conn->query($add_cart)) {
                die("Ошибка добавления в корзину: " . $conn->error);
            }
        }

        // Перенаправляем пользователя на страницу корзины
        header("Location: cart.php");
        exit();
    } else {
        echo "Некорректные данные: ID товара или количество.";
    }
} else {
    echo "Некорректный запрос.";
}
?>

<?php
session_start();
$conn = new mysqli("localhost", "root", "", "users_db");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id'];
    $product_id = $_POST['product_id'];

    // Проверка на наличие товара в корзине
    $sql = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $sql = "UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?";
    } else {
        $sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();

    header("Location: client_dashboard.php");
}
?>




