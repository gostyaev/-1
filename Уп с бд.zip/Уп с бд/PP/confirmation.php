<?php
// Подключаем соединение с базой данных
include('assets/php/connect.php');

// Получаем order_id из параметров URL
$order_id = $_GET['order_id'];

// Логируем order_id для отладки
echo "order_id: $order_id";

// SQL-запрос для получения данных о заказе
$sql = "SELECT * FROM orders WHERE id = $order_id";

// Выполнение запроса
$result = $conn->query($sql);

// Проверка на ошибки в запросе
if ($result === false) {
    die("Ошибка SQL: " . $conn->error);
}

if ($result->num_rows > 0) {
    $order = $result->fetch_assoc();
    // Выводим информацию о заказе
    echo "Заказ успешно найден!";
    // Дальше можно отображать информацию о заказе
    echo "Дата заказа: " . $order['order_date'] . "<br>";
    echo "Итоговая сумма: " . $order['total_amount'] . " руб.<br>";
} else {
    echo "Заказ не найден!";
}


