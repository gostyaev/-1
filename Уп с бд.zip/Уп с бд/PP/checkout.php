<?php
// Подключаем соединение с базой данных
include('assets/php/connect.php');

// Проверяем, что соединение с базой данных установлено
if (!$conn) {
    die("Ошибка: не удалось подключиться к базе данных.");
}

// Стартуем сессию, если еще не запущена
session_start();

// Получаем session_id пользователя
$user_session = session_id(); // Получаем session_id через глобальную переменную session_id()

// Проверяем, что пользователь авторизован и session_id существует
if (!isset($_SESSION['user_id'])) {
    die("Ошибка: пользователь не авторизован.");
}

// Получаем общую сумму корзины
$sql = "
    SELECT SUM(cart.quantity * products.price) AS total_sum
    FROM cart
    JOIN products ON cart.product_id = products.id
    WHERE cart.user_session = '$user_session'
";
$result = $conn->query($sql);
if ($result === false) {
    die("Ошибка SQL: " . $conn->error . "<br>");
}

$row = $result->fetch_assoc();
$total_sum = $row['total_sum'];

// Проверяем, есть ли товары в корзине
if ($total_sum > 0) {
    // Получаем user_id из сессии
    $user_id = $_SESSION['user_id'];

    // Добавляем заказ в таблицу orders
    $sql_insert_order = "
        INSERT INTO orders (user_id, order_date, total_amount, status)
        VALUES ($user_id, NOW(), $total_sum, 'pending')
    ";

    if ($conn->query($sql_insert_order) === TRUE) {
        // Получаем ID последнего добавленного заказа
        $order_id = $conn->insert_id;

        // Удаляем товары из корзины
        $sql_delete_cart = "
            DELETE FROM cart
            WHERE user_session = '$user_session'
        ";

        if ($conn->query($sql_delete_cart) === TRUE) {
            echo "Заказ оформлен успешно!";
            // Редирект на страницу с подтверждением или главную
            header("Location: confirmation.php?order_id=$order_id");
            exit();
        } else {
            echo "Ошибка при удалении товаров из корзины: " . $conn->error;
        }
    } else {
        echo "Ошибка при создании заказа: " . $conn->error;
    }
} else {
    echo "Корзина пуста!";
}
?>







