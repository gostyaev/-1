<?php
include 'db.php';

if (isset($_GET['cart_id'])) {
    $cart_id = intval($_GET['cart_id']);
    $delete_cart = "DELETE FROM cart WHERE id = $cart_id";
    $conn->query($delete_cart);
    header("Location: cart.php");
}
?>
