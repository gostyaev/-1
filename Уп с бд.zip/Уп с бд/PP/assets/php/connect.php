<?php
$servername = "localhost";
$username = "root"; // Ваш пользователь базы данных
$password = ""; // Ваш пароль (оставьте пустым, если нет пароля)
$dbname = "users_db"; // Имя вашей базы данных

$db = new mysqli($servername, $username, $password, $dbname);
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Ошибка: " . $conn->connect_error);
}
?>


